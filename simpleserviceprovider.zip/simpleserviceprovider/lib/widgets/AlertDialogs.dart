import 'package:flutter/material.dart';
import 'package:service_provider/interfaces/image_pick_interface.dart';
import 'package:service_provider/screens/enterpreneur_sign_up/admin_approval.dart';
import 'package:service_provider/screens/enterpreneur_sign_up/subscribe.dart';


import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

Widget invalidEmail(BuildContext context) {
  return SizedBox(
    height: 230,
    child: Column(
      children: [
        Container(
          height: 50,
          width: double.infinity,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(5)),
            color: app_color,
          ),
          child: Center(
              child: Text("Invalid Email", style: headingStyle20MBWhite())),
        ),
        const SizedBox(
          height: 50,
        ),
        Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            "TRY AGAIN",
            style: headingStyle20MBDarkGrey(),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 80.0),
            child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: button("OK")),
          )
        ])
      ],
    ),
  );
}

Widget passwordsNotMatch(BuildContext context) {
  return SizedBox(
    height: 230,
    child: Column(
      children: [
        Container(
          height: 50,
          width: double.infinity,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(5)),
            color: app_color,
          ),
          child: Center(
              child: Text("PASSWORDS DO NOT MATCH",
                  style: headingStyle20MBWhite())),
        ),
        const SizedBox(
          height: 50,
        ),
        Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            "TRY AGAIN",
            style: headingStyle20MBDarkGrey(),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 80.0),
            child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: button("OK")),
          )
        ])
      ],
    ),
  );
}

Widget invalidLogin(BuildContext context) {
  return SizedBox(
    height: 230,
    child: Column(
      children: [
        Container(
          height: 50,
          width: double.infinity,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(5)),
            color: app_color,
          ),
          child: Center(
              child: Text("INVALID LOGIN", style: headingStyle20MBWhite())),
        ),
        const SizedBox(
          height: 50,
        ),
        Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            "PLEASE TRY AGAIN",
            style: headingStyle20MBDarkGrey(),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 80.0),
            child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: button("OK")),
          )
        ])
      ],
    ),
  );
}

Widget addProfilePicture(BuildContext context) {
  return SizedBox(
    height: 230,
    child: Column(
      children: [
        Container(
          height: 50,
          width: double.infinity,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(5)),
            color: app_color,
          ),
          child: Center(
              child: Text("Finish Setup", style: headingStyle20MBWhite())),
        ),
        const SizedBox(
          height: 30,
        ),
        Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            "FIRST ADD PICTURE\nTO PROFILE",
            style: headingStyle20MBDarkGrey(),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 80.0),
            child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: button("OK")),
          )
        ])
      ],
    ),
  );
}

Widget pickImage(BuildContext context, PickImageListener imageListener) {
  return SizedBox(
    height: 230,
    child: Column(
      children: [
        Container(
          height: 50,
          width: double.infinity,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(5)),
            color: app_color,
          ),
          child: Center(
              child: Text("Choose an option", style: headingStyle20MBWhite())),
        ),
        const SizedBox(
          height: 30,
        ),
        Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          ListTile(
            contentPadding: const EdgeInsets.only(left: 40.0),
            onTap: () {
              imageListener.openCamera();
              Navigator.pop(context);
            },
            leading: Image.asset(
              "assets/icons/camera.png",
            ),
            title: Text(
              "Camera",
              style: headingStyle14MBDarkGrey(),
            ),
          ),
          ListTile(
            onTap: () {
              imageListener.openGallery();
              Navigator.pop(context);
            },
            contentPadding: const EdgeInsets.only(left: 40.0),
            leading: Image.asset("assets/icons/gallery.png"),
            title: Text(
              "Upload from gallery",
              style: headingStyle14MBDarkGrey(),
            ),
          )
        ])
      ],
    ),
  );
}

Widget subscribeAlertDialog(BuildContext context) {
  return SizedBox(
    height: 440,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(
          height: 30,
        ),
        Text(
          "Start your 14 days free trial NOW!",
          style: headingStyle16MBAppColor(),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 20),
        RadioListTile(
            value: 0,
            groupValue: 0,
            activeColor: app_color,
            onChanged: (v) {},
            title: Text("You can add one service")),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: GestureDetector(
              onTap: () {
                Navigator.pop(context);
                navigateForward(context, AdminApproval());
              },
              child: button("START NOW")),
        ),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 5,
                width: 100,
                color: app_color,
              ),
              const SizedBox(width: 20),
              Text(
                "OR",
                style: headingStyle16MBAppColor(),
              ),
              const SizedBox(width: 20),
              Container(
                height: 5,
                width: 100,
                color: app_color,
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        RadioListTile(
            value: 0,
            groupValue: 0,
            activeColor: app_color,
            onChanged: (v) {},
            title: Text("You can add multiple services")),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: GestureDetector(
              onTap: () {
                Navigator.pop(context);
                                                        navigateForward(context, Subscribe());

              },
              child: button("SUBSCRIBE!")),
        ),
      ],
    ),
  );
}

Widget creditCardDetails(BuildContext context,  setState   ,double amount) {
  bool paymentDetails = true;
  bool paymentDone = false;
  return SizedBox(
    height: 478,
    child: Stack(alignment: Alignment.bottomCenter, children: [
      Padding(
        padding: const EdgeInsets.only(left: 20.0, right: 20),
        child: Container(
          decoration: BoxDecoration(
              color: Color(0xffF5F5F5),
              borderRadius: BorderRadius.circular(15)),
          height: 458,
          child: Column(
            children: [
              Container(
                height: 120,
                width: double.infinity,
                decoration: const BoxDecoration(
                    color: Color(0xffD8D8D8),
                    border: Border(
                        bottom:
                            BorderSide(color: Color(0xffCCCCCC), width: 2))),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(height: 40),
                        Text(
                          "Enterpreneur",
                          style: headingStyle14MBDarkGrey(),
                        ),
                        Text("On Demand Services",
                            style: subHeadingStyle12MBGrey()),
                      ],
                    ),
                    Positioned(
                        top: 10,
                        left: 10,
                        child: GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Image.asset("assets/icons/close.png")))
                  ],
                ),
              ),
              Visibility(
                visible: paymentDetails,
                child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 40,
                    ),
                    child: Column(
                      children: [
                        TextFormField(
                            decoration: InputDecoration(
                                isDense: true,
                                fillColor: white,
                                filled: true,
                                hintText: "Email",
                                // contentPadding: EdgeInsets.symmetric(horizontal: 1),
                                hintStyle: headingStyle14MBBlack(),
                                prefixIconConstraints: BoxConstraints(
                                  minWidth: 30,
                                  minHeight: 25,
                                ),
                                prefixIcon:
                                    Image.asset("assets/icons/green_email.png"),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        color: Color(0xffCCCCCC)),
                                    borderRadius: BorderRadius.circular(5)),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: const BorderSide(
                                        color: Color(0xffCCCCCC)),
                                    borderRadius: BorderRadius.circular(5)))),
                        const SizedBox(
                          height: 20,
                        ),
                        Column(
                          children: [
                            TextFormField(
                                decoration: InputDecoration(
                                    isDense: true,
                                    fillColor: white,
                                    filled: true,
                                    hintText: "Card Number",
                                    prefixIconConstraints: BoxConstraints(
                                      minWidth: 30,
                                      minHeight: 25,
                                    ),
                                    hintStyle: headingStyle14MBBlack(),
                                    prefixIcon: Image.asset(
                                        "assets/icons/green_cc.png"),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Color(0xffCCCCCC)),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Color(0xffCCCCCC)),
                                    ))),
                            Row(
                              children: [
                                Expanded(
                                  child: TextFormField(
                                      decoration: InputDecoration(
                                          isDense: true,
                                          fillColor: white,
                                          filled: true,
                                          hintText: DateTime.now()
                                                  .day
                                                  .toString() +
                                              " / " +
                                              DateTime.now().year.toString(),
                                          // contentPadding: EdgeInsets.symmetric(horizontal: 1),
                                          hintStyle: headingStyle14MBBlack(),
                                          prefixIconConstraints: BoxConstraints(
                                            minWidth: 30,
                                            minHeight: 25,
                                          ),
                                          prefixIcon: Image.asset(
                                              "assets/icons/green_calendar.png"),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: Color(0xffCCCCCC)),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: Color(0xffCCCCCC)),
                                          ))),
                                ),
                                Expanded(
                                  child: TextFormField(
                                      decoration: InputDecoration(
                                          isDense: true,
                                          fillColor: white,
                                          filled: true,
                                          hintText: "CVV",
                                          // contentPadding: EdgeInsets.symmetric(horizontal: 1),
                                          hintStyle: headingStyle14MBBlack(),
                                          prefixIconConstraints: BoxConstraints(
                                            minWidth: 30,
                                            minHeight: 25,
                                          ),
                                          prefixIcon: Image.asset(
                                              "assets/icons/green_cvv.png"),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: Color(0xffCCCCCC)),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: Color(0xffCCCCCC)),
                                          ))),
                                ),
                              ],
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        GestureDetector(
                            onTap: () {
                              // Navigator.pop(context);
                              setState((){
                                print('sdhfbks');
                                paymentDetails = false ; 
                                paymentDone = true ;
                              });
                            },
                            child: button2("Pay \$$amount"))
                      ],
                    )),
              ),
              Visibility(
                  visible: paymentDone,
                  child: Column(
                    children: [
                      const SizedBox(height:20),
                      Text("YOUR MEMBERSHIP EXPIRES ON", style: subHeadingStyle12MBGrey(), )
                    ],
                  ))
            ],
          ),
        ),
      ),
      Positioned(
        top: 0,
        right: 0,
        left: 0,
        child: Container(
          height: 70,
          width: 70,
          padding: EdgeInsets.all(1),
          decoration: BoxDecoration(
            border: Border.all(
              width: 4,
              color: white,
            ),
            color: app_color,
            shape: BoxShape.circle,
          ),
        ),
      ),
    ]),
  );
}
