import 'package:flutter/material.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';

Widget button(String title) {
  return Container(
      height: 50,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15), color: app_color),
      child: Center(
        child: Text(title, style: headingStyle20MBWhite()),
      ));
}

Widget buttonWithIcon(String title, String iconPath) {
  return Container(
      height: 50,
      // width: 160,
      padding: const EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15), color: app_color),
      child: Center(
        child: Row(
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(iconPath),
            SizedBox(
              width: 5,
            ),
            Text(title, style: headingStyle20MBWhite()),
          ],
        ),
      ));
}

Widget button2(String title) {
  return Container(
      height: 50,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5), color: app_color),
      child: Center(
        child: Text(title, style: headingStyle20MBWhite()),
      ));
}

Widget signInAndSignupWhiteButton(String title) {
  return Container(
      height: 55,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12), color: Colors.white),
      child: Center(
        child: Text(title, style: headingStyle21MBAppColor()),
      ));
}
