import "package:flutter/material.dart" ;
import 'package:service_provider/screens/categories.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class HomeCategoriesList extends StatefulWidget {
  final String title ;
  final String iconPath;
  HomeCategoriesList(this.title,this.iconPath) ;
  @override
  _HomeCategoriesListState createState() => _HomeCategoriesListState();
}

class _HomeCategoriesListState extends State<HomeCategoriesList> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        navigateForward(context, Categories());
      },
          child: Padding(
        padding: EdgeInsets.symmetric(vertical: 10),
            child: Container(
          height: 80,
          width: double.infinity,
          padding:  EdgeInsets.symmetric(vertical: 10 , horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color:white,
            border: Border.all(
              color: app_color,
              width: 1
            )
          ),
          child: Row(
            // mainAxisAlignment: MainAxisAlignment.spaceBetween,

            children: [
            Image.asset(widget.iconPath),
            SizedBox(width:25),
            Expanded(
                        child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                Text(widget.title,style: headingStyle14MBDarkGrey(),),
                Text("75 found in your area", style: subHeadingStyle12MBGrey(),)
              ],),
            ),
            Icon(Icons.arrow_forward_ios, color: app_color,)
          ],),
          
        ),
      ),
    );
  }
}