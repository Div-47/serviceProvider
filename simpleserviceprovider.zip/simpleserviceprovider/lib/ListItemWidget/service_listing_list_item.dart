import "package:flutter/material.dart";
import 'package:service_provider/screens/edit_service.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class ServiceListItem extends StatefulWidget {
  ServiceListItem({Key? key}) : super(key: key);

  @override
  State<ServiceListItem> createState() => _ServiceListItemState();
}

class _ServiceListItemState extends State<ServiceListItem> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(10),
      child: Container(
        height: 100,
        color: white,
        padding: EdgeInsets.all(10),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Row(
            children: [
              Image.asset("assets/icons/green_ok.png"),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Tutor",
                      style: headingStyle21MBDarkGrey(),
                    ),
                    Text(
                      "Maths",
                      style: headingStyle21MBDarkGrey(),
                    )
                  ],
                ),
              ),
              GestureDetector(
                onTap: (){
                  navigateForward(context, EditService());
                },
                              child: Image.asset(
                  "assets/icons/service_edit.png",
                ),
              ),
            ],
          )
        ]),
      ),
    );
  }
}
