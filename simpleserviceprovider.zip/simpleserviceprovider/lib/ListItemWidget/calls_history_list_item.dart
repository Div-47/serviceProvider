import 'package:flutter/material.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class CallHistoryListItem extends StatefulWidget {
  CallHistoryListItem({Key? key}) : super(key: key);

  @override
  State<CallHistoryListItem> createState() => _CallHistoryListItemState();
}

class _CallHistoryListItemState extends State<CallHistoryListItem> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundImage: AssetImage("assets/icons/avatar.png"),
                  ),
                   Positioned(
                     bottom: 3,right:3,
                                        child: Container(height:8,width:8,
                  decoration: BoxDecoration(color: online_color,
                  borderRadius: BorderRadius.circular(24)
                  ),
                  ),
                   )
                ],
              ),
              SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Daniel Santio", style: headingStyle20MBDarkGrey()),
                    Image.asset("assets/icons/green_phone.png")
                   
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text("11:20 AM", style: headingStyle14MBDarkGrey()),

                
                ],
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left:65.0),
            child: Divider(),
          )
        ],
      ),
    );
  }
}
