import 'package:flutter/material.dart';
import 'package:service_provider/ListItemWidget/calls_history_list_item.dart';
import 'package:service_provider/ListItemWidget/chat_list_item.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class Chat extends StatefulWidget {
  Chat({Key? key}) : super(key: key);

  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: app_color,
          centerTitle: true,
          title: Text("Chat History", style: headingStyle20MBWhite()),
          bottom: PreferredSize(
            preferredSize: AppBar().preferredSize,
            child: const Material(
              child: TabBar(
                // controller: TabController(length: 2, vsync: this),
                // labelStyle: headingStyle14MBDarkGrey(),
                labelColor: darkGrey,
                tabs: [
                  Tab(
                    text: "Chats",
                  ),
                  Tab(
                    text: "Calls",
                  ),
                ],
              ),
            ),
          ),
        ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          child: TabBarView(
            children: [
              ListView.builder(
                  itemCount: 15,
                  padding: EdgeInsets.all(20),
                  // shrinkWrap: true,
                  // physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return ChatListItem();
                  }),
              ListView.builder(
                  itemCount: 15,
                    padding: EdgeInsets.all(20),
                  itemBuilder: (context, index) {
                    return CallHistoryListItem();
                  }),
            ],
          ),

          // padding: const EdgeInsets.only( left: 20, right: 20),
          // child: TabBarView(

          //   children: [

          // ])
        ),
      ),
    );
  }
}

// Padding(
//                 padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
//                 child: ListView.builder(
//                     itemCount: 15,
//                     // shrinkWrap: true,
//                     // physics: NeverScrollableScrollPhysics(),
//                     itemBuilder: (context, index) {
//                       return ChatListItem();
//                     }),
//               ),
