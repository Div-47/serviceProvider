import 'package:flutter/material.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class AudioCall extends StatefulWidget {
  AudioCall({Key? key}) : super(key: key);

  @override
  State<AudioCall> createState() => _AudioCallState();
}

class _AudioCallState extends State<AudioCall> {
  bool speaker = true;
  bool hold = false;
  bool mute = false;
  bool keypad = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: app_color,
        centerTitle: true,
        title: Text("Audio Call", style: headingStyle20MBWhite()),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: app_background_color,
        child: Column(
          children: [
            SizedBox(height: 30),
            Image.asset("assets/icons/avatar.png"),
            SizedBox(height: 15),
            Text(
              "RICHARD MOORS",
              style: headingStyle16MBDarkGrey(),
            ),
            SizedBox(height: 10),
            Text(
              "Duration 01:20",
              style: headingStyle14MBGrey(),
            ),
          ],
        ),
      ),
      bottomSheet: Container(
        height: MediaQuery.of(context).size.height * 0.5,
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
            color: white, borderRadius: BorderRadius.circular(25)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: GestureDetector(
                        onTap: () {
                          setState(() {
                            speaker = !speaker;
                          });
                        },
                        child: audioButtons(
                            speaker, "assets/icons/speaker.png", "Speaker")),
                  ),
                  // SizedBox(width: 80),
                  Expanded(
                    child: GestureDetector(
                        onTap: () {
                          setState(() {
                            hold = !hold;
                          });
                        },
                        child: audioButtons(
                            hold, "assets/icons/pause.png", "Hold")),
                  )
                ],
              ),
            ),
            SizedBox(height: 10),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: GestureDetector(
                        onTap: () {
                          setState(() {
                            mute = !mute;
                          });
                        },
                        child: audioButtons(
                            mute, "assets/icons/speaker.png", "Mute")),
                  ),
                  // SizedBox(width: 80),
                  Expanded(
                    child: GestureDetector(
                        onTap: () {
                          setState(() {
                            keypad = !keypad;
                          });
                        },
                        child: audioButtons(
                            keypad, "assets/icons/keypad.png", "KeyPad")),
                  ),
                ],
              ),
            ),
            SizedBox(height: 15),
            Image.asset("assets/icons/end_call.png")
          ],
        ),
      ),
    );
  }

  Widget audioButtons(bool enable, String iconPath, String title) {
    return Column(
      children: [
        Container(
          height: MediaQuery.of(context).size.height *.09,
          width: MediaQuery.of(context).size.height *.09,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(80),
              color: enable ? app_color : app_background_color),
          child: Image.asset(
            iconPath,
            color: enable ? white : app_color,
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          title,
          style: headingStyle21MBDarkGrey(),
          maxLines: 1,
          softWrap: false,
          overflow: TextOverflow.fade,
        )
      ],
    );
  }
}
