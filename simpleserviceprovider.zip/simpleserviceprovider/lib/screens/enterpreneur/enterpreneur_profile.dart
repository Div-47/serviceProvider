import "package:flutter/material.dart";
import 'package:service_provider/screens/enterpreneur/chat.dart';

import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

import 'audio_call.dart';

class EnterpreneurProfile extends StatefulWidget {
  @override
  _EnterpreneurProfileState createState() => _EnterpreneurProfileState();
}

class _EnterpreneurProfileState extends State<EnterpreneurProfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: app_background_color,
        child: SingleChildScrollView(
          child: Column(
            // crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 270,
                child: Stack(
                  children: [
                    SizedBox(
                      height: const Size.fromHeight(125.0).height,
                      child: AppBar(
                        backgroundColor: app_color,
                      ),
                    ),
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          top: 105,
                          right: 0,
                          left: 0,
                          child: Container(
                            height: 150,
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            decoration: BoxDecoration(
                              color: white,
                              borderRadius: BorderRadius.circular(25),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.5),
                                  spreadRadius: 1,
                                  blurRadius: 7,
                                  offset: Offset(
                                      1, 1), // changes position of shadow
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                            top: 50,
                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(1),
                                  decoration: BoxDecoration(
                                      color: white,
                                      borderRadius: BorderRadius.circular(15)),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image.asset(
                                        "assets/icons/avatar.png",
                                        fit: BoxFit.cover,
                                        height: 120,
                                        width: 120,
                                      )),
                                ),
                                const SizedBox(height: 15),
                                Text("RICHARD MOORS",
                                    style: headingStyle16MBDarkGrey()),
                                Text("TUTORS ==> PHYSICS",
                                    style: headingStyle16EBAppColor())
                              ],
                            ))
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20),
                        Text("A little bit about me.",
                            style: headingStyle16MBDarkGrey()),
                        Text(
                          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Faucibus enim tellus ut mauris tristique ut odio massa. Vestibulum egestas fringilla et orci. Magna eget sed eu vel vitae mauris eget. Pulvinar maecenas aliquet scelerisque aliquam a iaculis.",
                          style: headingStyle14MBGrey(),
                        ),
                        SizedBox(height: 40),
                        Text("What are my specialties?",
                            style: headingStyle16MBDarkGrey()),
                        Text(
                          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Faucibus enim tellus ut mauris tristique ut odio massa. Vestibulum egestas fringilla et orci. Magna eget sed eu vel vitae mauris eget. Pulvinar maecenas aliquet scelerisque aliquam a iaculis.",
                          style: headingStyle14MBGrey(),
                        ),
                        SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              Container(
                                height: 15,
                                width: 15,
                                decoration: BoxDecoration(
                                    color: online_color,
                                    borderRadius: BorderRadius.circular(25)),
                              ),
                              SizedBox(width: 20),
                              Text("I'm online",
                                  style: headingStyle14MBDarkGrey())
                            ],
                          ),
                        ),
                        SizedBox(height:40),
                       Padding(
                         padding: const EdgeInsets.symmetric(horizontal:10.0, vertical: 10),
                         child: Row(
                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                           children: [
                            GestureDetector(
                              onTap: (){
                                navigateForward(context, AudioCall()) ;
                              },
                              child: buttonWithIcon("Call Me", "assets/icons/phone.png")), GestureDetector(
                              onTap: (){
                                navigateForward(context, Chat());
                              },
                              child: buttonWithIcon("Let's Chat", "assets/icons/message.png"))
                         ],),
                       )
                      ]))
            ],
          ),
        ),
      ),
    );
  }
}
