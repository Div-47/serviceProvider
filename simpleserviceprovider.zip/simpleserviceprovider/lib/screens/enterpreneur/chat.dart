import 'package:flutter/material.dart';
import 'package:service_provider/screens/enterpreneur/audio_call.dart';

import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'dart:math' as math;

class Chat extends StatefulWidget {
  @override
  _ChatState createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  final TextEditingController message = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: app_color,
        
        centerTitle: true,
        title: Row(
          children: [
            SizedBox(width: 20),
            ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: Stack(
                  children: [
                    Image.asset(
                      "assets/icons/avatar.png",
                      height: 45,
                      width: 45,
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        height: 8,
                        width: 8,
                        decoration: BoxDecoration(
                            color: online_color,
                            borderRadius: BorderRadius.circular(24)),
                      ),
                    )
                  ],
                )),
            SizedBox(width: 10),
            Text(
              "Richard Moors",
              style: headingStyle20MBWhite(),
            )
          ],
        ),
        actions: [
          GestureDetector(
              onTap: () {
                navigateForward(context, AudioCall());
              },
              child: Image.asset("assets/icons/phone.png"))
        ],
      ),
      body: GestureDetector(
        onTap: () {},
        child: Container(
          height: double.infinity,
          width: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: GestureDetector(
            onTap: () {
              FocusScopeNode currentFocus = FocusScope.of(context);
              if (!currentFocus.hasPrimaryFocus) {
                currentFocus.unfocus();
              }
            },
            child: Column(children: [
              Expanded(
                child: ListView.builder(
                    itemCount: 2,
                    shrinkWrap: true,
                    physics: AlwaysScrollableScrollPhysics(),
                    itemBuilder: (context, index) {
                      // if(index/2 ==0)
                      return index / 2 == 0 ? receivedChatUi() : sentChatUi();
                    }),
              )
            ]),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: EdgeInsets.only(
              top: 10,
              left: 10,
              bottom: MediaQuery.of(context).viewInsets.bottom + 10,
              right: 10),
          child: Row(
            children: [
              Image.asset("assets/icons/add_app_color.png"),
              Expanded(
                  child: Padding(
                padding: EdgeInsets.only(
                  left: 10,
                  right: 10,
                ),
                child: Container(
                  padding: EdgeInsets.only(left: 10, right: 10),
                  decoration: BoxDecoration(
                      color: Color(0xffEFEFF4),
                      borderRadius: BorderRadius.circular(15)),
                  child: TextField(
                      minLines: 1,
                      maxLines: 5,
                      controller: message,
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Write a comment",
                          hintStyle: headingStyle16MBDarkGrey())),
                ),
              )),
              Image.asset("assets/icons/send_app_color.png"),
            ],
          ),
        ),
      ),
    );
  }

  Widget receivedChatUi() {
    return Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset("assets/icons/avatar2.png", height: 50),
            SizedBox(width: 10),
            Transform(
              alignment: Alignment.center,
              transform: Matrix4.rotationY(math.pi),
              child: CustomPaint(
                painter: Triangle(Color(0xffF1F1F1)),
              ),
            ),
            Flexible(
              child: Container(
                padding: const EdgeInsets.all(15),
                margin: const EdgeInsets.only(bottom: 5),
                decoration: BoxDecoration(
                  color: Color(0xffF1F1F1),
                  borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(19),
                    bottomLeft: Radius.circular(19),
                    bottomRight: Radius.circular(19),
                  ),
                ),
                child: Text(
                  "Hi Richard. I am Selena Lennis. I am looking for a Physics Tutor to help my 14 year old daughter.",
                  style: const TextStyle(color: Colors.black, fontSize: 15),
                ),
              ),
            ),
          ],
        ));
  }

  Widget sentChatUi() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Flexible(
          child: Container(
            padding: const EdgeInsets.all(15),
            margin: const EdgeInsets.only(bottom: 5),
            decoration: BoxDecoration(
              color: app_color,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(19),
                bottomLeft: Radius.circular(19),
                bottomRight: Radius.circular(19),
              ),
            ),
            child: Text(
              "Hi Selena. Thanks for contacting me. I’ll be happy to help your daughter. I will need a little more info if that’s ok?",
              style: const TextStyle(color: Colors.white, fontSize: 15),
            ),
          ),
        ),
        CustomPaint(painter: Triangle(app_color)),
        SizedBox(width: 10),
        Image.asset("assets/icons/avatar.png", height: 50),
      ],
    );
  }
}

class Triangle extends CustomPainter {
  final Color backgroundColor;
  Triangle(this.backgroundColor);

  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint()..color = backgroundColor;

    var path = Path();
    path.lineTo(-5, 0);
    path.lineTo(0, 10);
    path.lineTo(5, 0);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}
