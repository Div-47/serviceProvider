import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:service_provider/screens/customer_sign_up/register.dart';
import 'package:service_provider/screens/homepage.dart';

import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

import 'enterpreneur_sign_up/register.dart';

class CurrentPackage extends StatefulWidget {
  const CurrentPackage({Key? key}) : super(key: key);

  @override
  _CurrentPackageState createState() => _CurrentPackageState();
}

class _CurrentPackageState extends State<CurrentPackage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          centerTitle: true,

          backgroundColor: Colors.transparent,
          // title: Text("Signxxx Up", style: headingStyle20MBWhite()),
        ),
        body: GestureDetector(
            onTap: () {
              FocusScopeNode currentFocus = FocusScope.of(context);

              if (!currentFocus.hasPrimaryFocus) {
                currentFocus.unfocus();
              }
            },
            child: Container(
                height: double.infinity,
                width: double.infinity,
                color: app_color,
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset("assets/icons/current_package.png"),
                      const SizedBox(height: 50),
                      Text("Current Package",style:headingStyle27MBWhite() ) ,
                        const SizedBox(height: 30),
                      Text("12 days left", style: headingStyle27MBWhite()
                       ),
                        const SizedBox(height: 200),
                        GestureDetector(
                          onTap: (){
                            navigateForward(context, Homepage("provider"));
                          },
                          child: signInAndSignupWhiteButton("Continue"))
                    ]))));
  }
}
