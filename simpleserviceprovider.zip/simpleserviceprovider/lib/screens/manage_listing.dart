import "package:flutter/material.dart";
import 'package:service_provider/ListItemWidget/service_listing_list_item.dart';
import 'package:service_provider/screens/add_listings.dart';
import 'package:service_provider/screens/edit_service.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

class ManageListing extends StatefulWidget {
  ManageListing({Key? key}) : super(key: key);

  @override
  State<ManageListing> createState() => _ManageListingState();
}

class _ManageListingState extends State<ManageListing> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
      centerTitle: true,
      backgroundColor: app_color,
      title: Text("Service Listings", style: headingStyle20MBWhite()),
    ),
    body: Container(
      height: double.infinity,
      width:double.infinity,
      padding: EdgeInsets.symmetric(vertical:20,horizontal:20),
      child: Column(
        children:[
          Expanded(child: 
          ListView.builder(
            itemCount: 4,
            itemBuilder: (context,index) {
            return ServiceListItem();
          })
          ,)
        ]
      ),
    ),
    bottomSheet: Container(
      height:150,
      padding: EdgeInsets.only(left:20,right:20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(child: GestureDetector(
            onTap: (){
              navigateForward(context, AddService());
            },
            child: button("Add A Listing"))),
        ],
      )
    ),
    );
  }
}
