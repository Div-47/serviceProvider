import "package:flutter/material.dart";
import 'package:service_provider/ListItemWidget/home_categories.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<String> categoriesIconsPath = [
    "assets/icons/home_repair.png",
    "assets/icons/home_cleaning.png",
    "assets/icons/tutors.png",
    "assets/icons/car_maintainence.png",
    "assets/icons/transportation.png",
    "assets/icons/other.png"
  ];
  List<String> categoriesTitle = [
    "Home Repair",
    "Home Cleaning",
    "Tutors",
    "Car Maintainance",
    "Transportation",
    "Other"
  ];
  @override
  Widget build(BuildContext context) {
    return Expanded(
          child: Scaffold(
        appBar: AppBar(
                  centerTitle: true,

          backgroundColor: app_color,
          title: Text("Home", style: headingStyle20MBWhite()),
        ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          child: Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: EdgeInsets.all(20),
                    itemCount: categoriesIconsPath.length,
                    itemBuilder: (context, index) {
                      return HomeCategoriesList(
                          categoriesTitle[index], categoriesIconsPath[index]);
                    }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
