import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:service_provider/screens/sign_in.dart';
import 'package:service_provider/screens/sign_up.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class Welcome extends StatefulWidget {
  const Welcome({Key? key}) : super(key: key);

  @override
  _WelcomeState createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0,
                centerTitle: true,

        backgroundColor: Colors.transparent,
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: app_color,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          SvgPicture.asset("assets/icons/sign_in.svg"),
          const SizedBox(height: 10),
          Text("Uncomplicated\nStraightforward\nEffordless",
          textAlign: TextAlign.center,
              style: headingStyle27MBWhite()),
                      const SizedBox(height: 30,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal:40.0),
                        child: GestureDetector(
                          onTap: (){
                            navigateForward(context, const SignIn());
                          },
                          child: signInAndSignupButton("Sign In")),
                      ),
                       const SizedBox(height: 15,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal:40.0),
                        child: GestureDetector(
                          onTap: (){
                             navigateForward(context, const SignUp());
                          },
                          child: signInAndSignupButton("Sign Up")),
                      )
        ]),
      ),
    );
  }

  Widget signInAndSignupButton(String title) {
    return Container(
      height: 45,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal : 10),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),color: Colors.white),
      child: Center(
        child: Text(title, style: headingStyle21MBAppColor()),
      )
      
    );
  }
}
