import "package:flutter/material.dart";
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

class EditService extends StatefulWidget {
  EditService({Key? key}) : super(key: key);

  @override
  State<EditService> createState() => _EditServiceState();
}

class _EditServiceState extends State<EditService> {
  TextEditingController aboutController = TextEditingController();
  TextEditingController specialityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: app_color,
        title: Text("Edit/Delete", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: (){
             FocusScopeNode currentFocus = FocusScope.of(context);
            if (!currentFocus.hasPrimaryFocus) {
              currentFocus.unfocus();
            }
        },
              child: Container(
          height: double.infinity,
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: SingleChildScrollView(
                    child: Column(
              children: [
                SizedBox(height: 20),
                Container(
                  height: 45,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: darkGrey, width: 1)),
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            "Transportion",
                            style: headingStyle14MBDarkGrey(),
                          ),
                        ),
                      ),
                      Container(
                        height: 45,
                        width: 45,
                        color: app_color,
                        child: Icon(
                          Icons.arrow_drop_down,
                          color: white,
                          size: 34,
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  height: 45,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: darkGrey, width: 1)),
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            "Carpool",
                            style: headingStyle14MBDarkGrey(),
                          ),
                        ),
                      ),
                      Container(
                        height: 45,
                        width: 45,
                        color: app_color,
                        child: Icon(
                          Icons.arrow_drop_down,
                          color: white,
                          size: 34,
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                textBox(aboutController, "A little bit about me:"),
                 SizedBox(
                  height: 20,
                ),
                 textBox(specialityController, "My specialities are:")
                 , SizedBox(
                  height: 20,
                ),
                Row(children: [
                  Expanded(child: button("Save")),
                  SizedBox(
                  width: 10,
                ),
                    Expanded(child: button("Delete")),

                ],)
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget textBox(TextEditingController controller, String title) {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(border: Border.all(color: darkGrey), borderRadius: BorderRadius.circular(5) ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // DropdownButton( 
            
          //   items: ["items","1","2"].map((String items) {
          //       return DropdownMenuItem(
          //         value: items,
          //         child: Text(items),
          //       );
          //     }).toList(), onChanged: (v){}),
          Text(title,style: headingStyle14MBDarkGrey(),),
          TextField(
            controller: controller..text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque, venenatis leo ante morbi magnis porttitor. Massa ut mauris id aliquam at dapibus dignissim aliquam. In porta arcu, purus amet ipsum, aliquet tortor. Amet, bibendum erat iaculis in ipsum integer.",
            maxLines: 10,
            decoration: InputDecoration(
              focusedBorder: InputBorder.none ,
              enabledBorder: InputBorder.none
            ),
          ),
        ],
      ),
    );
  }
}
