import 'dart:io';

import "package:flutter/material.dart";
import 'package:service_provider/interfaces/image_pick_interface.dart';

import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/camera_and_gallery_utility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';
import 'package:service_provider/widgets/buttons.dart';

class ProfileUpdate extends StatefulWidget {
  final String user;
  ProfileUpdate({Key? key, required this.user}) : super(key: key);

  @override
  _ProfileUpdateState createState() => _ProfileUpdateState();
}

class _ProfileUpdateState extends State<ProfileUpdate>
    implements PickImageListener {
  File? profileImage;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Scaffold(
        body: GestureDetector(
          onTap: () {
            FocusScopeNode currentFocus = FocusScope.of(context);
            if (!currentFocus.hasPrimaryFocus) {
              currentFocus.unfocus();
            }
          },
          child: Container(
            height: double.infinity,
            width: double.infinity,
            color: app_background_color,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: 270,
                    child: Stack(
                      children: [
                        SizedBox(
                          height: const Size.fromHeight(115.0).height,
                          child: AppBar(
                            backgroundColor: app_color,
                          ),
                        ),
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            Positioned(
                              top: 105,
                              right: 0,
                              left: 0,
                              child: Container(
                                height: 150,
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 20),
                                decoration: const BoxDecoration(
                                    color: white,
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(15),
                                        topRight: Radius.circular(15))),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(right: 18.0),
                                      child: GestureDetector(
                                        onTap: () {
                                          showDilaogBox(context,
                                              pickImage(context, this));
                                        },
                                        child: Container(
                                            height: 40,
                                            decoration: BoxDecoration(
                                                color: app_color,
                                                borderRadius:
                                                    BorderRadius.circular(25)),
                                            child: Image.asset(
                                                "assets/icons/camera.png")),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                                top: 50,
                                child: Column(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(1),
                                      decoration: BoxDecoration(
                                          color: white,
                                          borderRadius:
                                              BorderRadius.circular(15)),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20),
                                        child: profileImage == null
                                            ? Image.asset(
                                                widget.user == "customer"
                                                    ? "assets/icons/avatar2.png"
                                                    : "assets/icons/avatar.png",
                                                fit: BoxFit.cover,
                                                height: 120,
                                                width: 120,
                                              )
                                            : Image.file(
                                                profileImage!,
                                                fit: BoxFit.cover,
                                                height: 120,
                                                width: 120,
                                              ),
                                      ),
                                    ),
                                    const SizedBox(height: 15),
                                    Text(
                                        widget.user == "customer"
                                            ? "SELENA LENNIS"
                                            : "Richard Moors",
                                        style: headingStyle14MBDarkGrey()),
                                    Text(
                                        widget.user == "customer"
                                            ? "Freelab88@gmail.com"
                                            : "Richardmoors@gmail.com",
                                        style: headingStyle14MBDarkGrey())
                                  ],
                                ))
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 465,
                    child: Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 20.0, right: 20),
                          child: Container(
                            height: 440,
                            width: double.infinity,
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                color: white,
                                borderRadius: BorderRadius.circular(15)),
                            child: Column(
                              children: [
                                TextFormField(
                                  decoration: InputDecoration(
                                      labelText: 'Name',
                                      contentPadding: const EdgeInsets.fromLTRB(
                                          10, 0, 10, 0),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      )),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                TextFormField(
                                  decoration: InputDecoration(
                                      labelText: 'Email',
                                      contentPadding: const EdgeInsets.fromLTRB(
                                          10, 0, 10, 0),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      )),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                TextFormField(
                                  decoration: InputDecoration(
                                      labelText: 'Phone Number',
                                      contentPadding: const EdgeInsets.fromLTRB(
                                          10, 0, 10, 0),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      )),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                TextFormField(
                                  obscureText: true,
                                  decoration: InputDecoration(
                                      labelText: 'Password',
                                      contentPadding: const EdgeInsets.fromLTRB(
                                          10, 0, 10, 0),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      )),
                                )
                              ],
                            ),
                          ),
                        ),
                        Align(
                            alignment: Alignment.bottomCenter,
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 50.0),
                              child: GestureDetector(
                                  onTap: () {
                                    // showDilaogBox(
                                    //     context, subscribeAlertDialog(context)).then((value) {
                                    //     });
                                  },
                                  child: button("Update")),
                            ))
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void openCamera() async {
    print("open camera");

    await pickFromCamera().then((value) {
      setState(() {
        profileImage = value;
      });
    });

    // TODO: implement openCamera
  }

  @override
  void openGallery() async {
    await pickFromGallery().then((value) {
      setState(() {
        profileImage = value;
      });
    });

    print("open gallery");

    // TODO: implement openGallery
  }
}
