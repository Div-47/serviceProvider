import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:service_provider/screens/customer_sign_up/register.dart';


import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

import 'enterpreneur_sign_up/register.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0,
                centerTitle: true,

        backgroundColor: Colors.transparent,
        // title: Text("Signxxx Up", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);

          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
            height: double.infinity,
            width: double.infinity,
            color: app_color,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset("assets/icons/sign_up.png"),
                const SizedBox(height: 150),
                GestureDetector(
                    onTap: () {
                      navigateForward(context, CustomerRegister());
                    },
                    child: signInAndSignupWhiteButton("Continue as Customer")),
                const SizedBox(height: 20),
                GestureDetector(
                   onTap: () {
                      navigateForward(context, Register());
                    },
                  child: signInAndSignupWhiteButton("Continue as Enterpreneur")),
              ],
            )),
      ),
    );
  }

 
}
