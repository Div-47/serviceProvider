import "package:flutter/material.dart";
import 'package:service_provider/screens/sign_up.dart';
import 'package:service_provider/screens/welcome.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

class AdminApproval extends StatefulWidget {
  AdminApproval({Key? key}) : super(key: key);

  @override
  _AdminApprovalState createState() => _AdminApprovalState();
}

class _AdminApprovalState extends State<AdminApproval> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            automaticallyImplyLeading: false  ,
            leading: new IconButton(
                icon: new Icon(Icons.arrow_back_ios),
                onPressed: () {
                 Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                  builder: (context) => SignUp()),
                              (Route<dynamic> route) => false);
                })),
        body: GestureDetector(
            onTap: () {
              FocusScopeNode currentFocus = FocusScope.of(context);

              if (!currentFocus.hasPrimaryFocus) {
                currentFocus.unfocus();
              }
            },
            child: Container(
              height: double.infinity,
              width: double.infinity,
              color: app_color,
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset("assets/icons/waiting.png"),
                    const SizedBox(height: 80),
                    Text(
                      "Waiting for\nAdmin Approval",
                      textAlign: TextAlign.center,
                      style: headingStyle27MBWhite(),
                    ),
                    const SizedBox(height: 200),
                    GestureDetector(
                        onTap: () {
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                  builder: (context) => Welcome()),
                              (Route<dynamic> route) => false);
                        },
                        child: signInAndSignupWhiteButton("Continue"))
                  ]),
            )));
  }
}
