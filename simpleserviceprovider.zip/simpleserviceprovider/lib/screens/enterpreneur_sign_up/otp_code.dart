import "package:flutter/material.dart";
import 'package:service_provider/screens/enterpreneur_sign_up/add_profile.dart';

import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';
import 'package:service_provider/widgets/buttons.dart';

class OtpCode extends StatefulWidget {
  OtpCode({Key? key}) : super(key: key);

  @override
  _OtpCodeState createState() => _OtpCodeState();
}

class _OtpCodeState extends State<OtpCode> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: app_color,
        title: Text("OTP CODE", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          child: SafeArea(
              child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(
                  height: 40,
                ),
                Container(
                  height: MediaQuery.of(context).size.height * .75,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5), color: white),
                  child: Column(children: [
                    const SizedBox(
                      height: 40,
                    ),
                    Text(
                      "Enter the otp code we texted to you phone number.",
                      style: headingStyle14MBDarkGrey(),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(
                      height: 70,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _textFieldOTP(first: true, last: false),
                        const SizedBox(width: 10),
                        _textFieldOTP(first: false, last: false),
                        const SizedBox(width: 10),
                        _textFieldOTP(first: false, last: false),
                        const SizedBox(width: 10),
                        _textFieldOTP(first: false, last: true)
                      ],
                    ),
                    const SizedBox(
                      height: 70,
                    ),
                    Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "No Code Recieved?",
                              style: headingStyle14MBDarkGrey(),
                            ),
                            Text(
                              "Resend Now!",
                              style: headingStyle16MBAppColor(),
                            )
                          ],
                        )),
                    const SizedBox(
                      height: 70,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: GestureDetector(
                          onTap: () {
                            navigateForward(context,EnterpreneurProfileScreen());
                            showDilaogBox(context, addProfilePicture(context));
                          },
                          child: button("Continue")),
                    )
                  ]),
                )
              ],
            ),
          )),
        ),
      ),
    );
  }

  Widget _textFieldOTP({bool? first, last}) {
    return Container(
      // padding: EdgeInsets.only(left:5,right:5),

      height: 65,
      child: AspectRatio(
        aspectRatio: 0.9,
        child: TextField(
          autofocus: true,
          onChanged: (value) {
            if (value.length == 1 && last == false) {
              FocusScope.of(context).nextFocus();
            }
            if (value.isEmpty && first == false) {
              FocusScope.of(context).previousFocus();
            }
          },
          showCursor: false,
          readOnly: false,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          keyboardType: TextInputType.number,
          maxLength: 1,
          decoration: InputDecoration(
            counter: Offstage(),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 2, color: Colors.black12),
                borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 2, color: Colors.purple),
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ),
    );
  }
}
