import "package:flutter/material.dart";
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:service_provider/screens/enterpreneur_sign_up/admin_approval.dart';

import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';
import 'package:service_provider/widgets/buttons.dart';

class Subscribe extends StatefulWidget {
  Subscribe({Key? key}) : super(key: key);

  @override
  _SubscribeState createState() => _SubscribeState();
}

class _SubscribeState extends State<Subscribe> {
  bool paymentDetails = true;
  bool paymentDone = false;
  bool basic = true;
  bool silver = false;
  bool premium = false;
  int paymentGroupValue = -1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: app_color,
        centerTitle: true,
        title: Text("Subscribe", style: headingStyle20MBWhite()),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: app_background_color,
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        child: SafeArea(
            child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 50),
              GestureDetector(
                  onTap: () {
                    setState(() {
                      basic = true;
                      silver = false;
                      premium = false;
                    });
                  },
                  child: subscription(basic, 2, 2, "Basic", "10.00")),
              const SizedBox(height: 20),
              GestureDetector(
                  onTap: () {
                    setState(() {
                      basic = false;
                      silver = true;
                      premium = false;
                    });
                  },
                  child: subscription(silver, 3, 3, "Silver", "20.00")),
              const SizedBox(height: 20),
              GestureDetector(
                  onTap: () {
                    setState(() {
                      basic = false;
                      silver = false;
                      premium = true;
                    });
                  },
                  child: subscription(premium, 6, 6, "Premium", "30.00")),
              const SizedBox(height: 20),
              paypal(),
              const SizedBox(height: 10),
              stripe(),
              const SizedBox(height: 30),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GestureDetector(
                      onTap: () {
                        showDialog(
                            useSafeArea: true,
                            barrierDismissible: true,
                            context: context,
                            builder: (context) {
                              return Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(20.0),
                                  child: StatefulBuilder(
                                      builder: (context, setSta) {
                                    return Material(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(5),
                                      child: creditCardDetails(
                                          context, "10.00", setSta),
                                    );
                                  }),
                                ),
                              );
                            });
                      },
                      child: button("Continue")))
            ],
          ),
        )),
      ),
    );
  }

  Widget subscription(bool selected, int services, int month,
      String subscriptionType, String amount) {
    return Container(
      height: 100,
      padding: EdgeInsets.only(right: 20),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? app_color : white),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                Checkbox(
                  checkColor: app_color,
                  fillColor: MaterialStateProperty.all(white),
                  value: selected,
                  shape: CircleBorder(),
                  onChanged: (bool? value) {
                    setState(() {
                      // selected = value!;
                    });
                  },
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      subscriptionType,
                      style: selected
                          ? headingStyle20MBWhite()
                          : headingStyle20MBDarkGrey(),
                    ),
                    Text(
                      "$month months access",
                      style: selected
                          ? headingStyle14MBWhite()
                          : headingStyle14MBDarkGrey(),
                    ),
                    Text(
                      "$services service listings",
                      style: selected
                          ? headingStyle14MBWhite()
                          : headingStyle14MBDarkGrey(),
                    )
                  ],
                )
              ],
            ),
          ),
          Text(
            "\$$amount",
            style:
                selected ? headingStyle20MBWhite() : headingStyle20MBDarkGrey(),
          )
        ],
      ),
    );
  }

  Widget paypal() {
    return Container(
      height: 65,
      padding: EdgeInsets.only(left: 5, right: 10),
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Color(0xffDBDBDB))),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                Radio(
                    activeColor: app_color,
                    value: 0,
                    groupValue: paymentGroupValue,
                    onChanged: (v) {
                      setState(() {
                        paymentGroupValue = 0;
                      });
                    }),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Pay with Paypal", style: headingStyle14MBDarkGrey()),
                    Text("Transaction fees may apply",
                        style: subHeadingStyle12MBGrey()),
                  ],
                )
              ],
            ),
          ),
          Image.asset("assets/icons/paypal.png")
        ],
      ),
    );
  }

  Widget stripe() {
    return Container(
      height: 65,
      padding: EdgeInsets.only(left: 5, right: 10),
      decoration:
          BoxDecoration(border: Border.all(width: 1, color: Color(0xffDBDBDB))),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                Radio(
                    activeColor: app_color,
                    value: 1,
                    groupValue: paymentGroupValue,
                    onChanged: (v) {
                      setState(() {
                        paymentGroupValue = 1;
                      });
                    }),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Pay with Credit Card",
                        style: headingStyle14MBDarkGrey()),
                    Text("Free of charge", style: subHeadingStyle12MBGrey()),
                  ],
                )
              ],
            ),
          ),
          Image.asset("assets/icons/stripe.png")
        ],
      ),
    );
  }

  Widget creditCardDetails(BuildContext context, String amount, setState) {
    return SizedBox(
      height: 500,
      child: Stack(alignment: Alignment.bottomCenter, children: [
        Padding(
          padding: const EdgeInsets.only(left: 20.0, right: 20),
          child: Container(
            decoration: BoxDecoration(
                color: Color(0xffF5F5F5),
                borderRadius: BorderRadius.circular(15)),
            height: 470,
            child: Column(
              children: [
                Container(
                  height: 120,
                  width: double.infinity,
                  decoration: const BoxDecoration(
                      color: Color(0xffD8D8D8),
                      border: Border(
                          bottom:
                              BorderSide(color: Color(0xffCCCCCC), width: 2))),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(height: 40),
                          Text(
                            "Enterpreneur",
                            style: headingStyle14MBDarkGrey(),
                          ),
                          Text(
                              paymentDetails
                                  ? "On Demand Services"
                                  : "THANK YOU FOR YOUR PAYMENT",
                              style: subHeadingStyle12MBGrey()),
                        ],
                      ),
                      paymentDetails
                          ? Positioned(
                              top: 10,
                              left: 10,
                              child: GestureDetector(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Image.asset("assets/icons/close.png")))
                          : SizedBox()
                    ],
                  ),
                ),
                Visibility(
                  visible: paymentDetails,
                  child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: 40,
                        vertical: 40,
                      ),
                      child: Column(
                        children: [
                          TextFormField(
                              decoration: InputDecoration(
                                  isDense: true,
                                  fillColor: white,
                                  filled: true,
                                  hintText: "Email",
                                  // contentPadding: EdgeInsets.symmetric(horizontal: 1),
                                  hintStyle: headingStyle14MBBlack(),
                                  prefixIconConstraints: BoxConstraints(
                                    minWidth: 30,
                                    minHeight: 25,
                                  ),
                                  prefixIcon: Image.asset(
                                      "assets/icons/green_email.png"),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Color(0xffCCCCCC)),
                                      borderRadius: BorderRadius.circular(5)),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Color(0xffCCCCCC)),
                                      borderRadius: BorderRadius.circular(5)))),
                          const SizedBox(
                            height: 20,
                          ),
                          Column(
                            children: [
                              TextFormField(
                                  decoration: InputDecoration(
                                      isDense: true,
                                      fillColor: white,
                                      filled: true,
                                      hintText: "Card Number",
                                      prefixIconConstraints: BoxConstraints(
                                        minWidth: 30,
                                        minHeight: 25,
                                      ),
                                      hintStyle: headingStyle14MBBlack(),
                                      prefixIcon: Image.asset(
                                          "assets/icons/green_cc.png"),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            color: Color(0xffCCCCCC)),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            color: Color(0xffCCCCCC)),
                                      ))),
                              Row(
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                        decoration: InputDecoration(
                                            isDense: true,
                                            fillColor: white,
                                            filled: true,
                                            hintText: DateTime.now()
                                                    .day
                                                    .toString() +
                                                " / " +
                                                DateTime.now().year.toString(),
                                            // contentPadding: EdgeInsets.symmetric(horizontal: 1),
                                            hintStyle: headingStyle14MBBlack(),
                                            prefixIconConstraints:
                                                BoxConstraints(
                                              minWidth: 30,
                                              minHeight: 25,
                                            ),
                                            prefixIcon: Image.asset(
                                                "assets/icons/green_calendar.png"),
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: const BorderSide(
                                                  color: Color(0xffCCCCCC)),
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: const BorderSide(
                                                  color: Color(0xffCCCCCC)),
                                            ))),
                                  ),
                                  Expanded(
                                    child: TextFormField(
                                        keyboardType: TextInputType.number,
                                        inputFormatters: [
                                          MaskTextInputFormatter(mask: "###"),
                                        ],
                                        decoration: InputDecoration(
                                            isDense: true,
                                            //  counter: Offstage(),
                                            fillColor: white,
                                            filled: true,
                                            hintText: "CVV",

                                            // contentPadding: EdgeInsets.symmetric(horizontal: 1),
                                            hintStyle: headingStyle14MBBlack(),
                                            prefixIconConstraints:
                                                BoxConstraints(
                                              minWidth: 30,
                                              minHeight: 25,
                                            ),
                                            prefixIcon: Image.asset(
                                                "assets/icons/green_cvv.png"),
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: const BorderSide(
                                                  color: Color(0xffCCCCCC)),
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: const BorderSide(
                                                  color: Color(0xffCCCCCC)),
                                            ))),
                                  ),
                                ],
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 35,
                          ),
                          GestureDetector(
                              onTap: () {
                                // Navigator.pop(context);

                                setState(() {
                                  paymentDetails = false;
                                  paymentDone = true;
                                });
                              },
                              child: button2("Pay \$$amount"))
                        ],
                      )),
                ),
                Visibility(
                    visible: paymentDone,
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: 40,
                        vertical: 40,
                      ),
                      child: Column(
                        children: [
                          // const SizedBox(height: 20),
                          Text(
                            "YOUR MEMBERSHIP EXPIRES ON",
                            style: subHeadingStyle12MBGrey(),
                          ),
                          const SizedBox(height: 10),
                          Container(
                              height: 45,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                  color: white,
                                  borderRadius: BorderRadius.circular(5),
                                  border: Border.all(
                                      width: 1, color: Color(0xffCCCCCC))),
                              child: Center(
                                  child: Text(
                                "DECEMBER 21, 2022",
                                style: headingStyle14MBBlack(),
                              ))),
                          const SizedBox(height: 40),
                          Text(
                            "YOU CAN ADD A TOTAL OF",
                            style: subHeadingStyle12MBGrey(),
                          ),
                          const SizedBox(height: 10),
                          Container(
                              height: 45,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                  color: white,
                                  borderRadius: BorderRadius.circular(5),
                                  border: Border.all(
                                      width: 1, color: Color(0xffCCCCCC))),
                              child: Center(
                                  child: Text(
                                "3 LISTINGS",
                                style: headingStyle14MBBlack(),
                              ))),
                          const SizedBox(height: 31),

                          GestureDetector(
                              onTap: () {
                                // Navigator.pop(context);
                                setState(() {
                                  paymentDetails = true;
                                  paymentDone = false;
                                });
                                navigateForward(context, AdminApproval());
                              },
                              child: button2("DONE"))
                        ],
                      ),
                    ))
              ],
            ),
          ),
        ),
        Positioned(
          top: 0,
          right: 0,
          left: 0,
          child: Container(
            height: 70,
            width: 70,
            padding: EdgeInsets.all(1),
            decoration: BoxDecoration(
              border: Border.all(
                width: 4,
                color: white,
              ),
              color: app_color,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ]),
    );
  }
}
