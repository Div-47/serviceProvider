import "package:flutter/material.dart";
import 'package:service_provider/screens/customer_sign_up/otp_code.dart';

import 'package:service_provider/screens/homepage.dart';

import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:country_picker/country_picker.dart';
import 'package:country_list_pick/country_list_pick.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:service_provider/utility.dart/validation.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';
import 'package:service_provider/widgets/buttons.dart';

class CustomerRegister extends StatefulWidget {
  CustomerRegister({Key? key}) : super(key: key);

  @override
  _CustomerRegisterState createState() => _CustomerRegisterState();
}

class _CustomerRegisterState extends State<CustomerRegister> {
  final _formKey = GlobalKey<FormState>();
// late  Country country ;
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: app_color,
                centerTitle: true,

        title: Text("Register", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          child: SafeArea(
              child: Form(
            key: _formKey,
            child: SingleChildScrollView(
                          child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 80,),
                  Container(
                    height: 65,
                    padding: EdgeInsets.only(left: 10, right: 10),
                    decoration: BoxDecoration(
                        color: white, borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      children: [
                        SizedBox(
                          child: CountryListPick(
                            theme: CountryTheme(
                              isShowFlag: true,
                              isShowTitle: false,
                              isShowCode: true,
                              isDownIcon: false,
                              showEnglishName: false,
                            ),
                            appBar: AppBar(
                              backgroundColor: app_color,
                              title: Text("Select Country",
                                  style: headingStyle20MBWhite()),
                            ),
                            useUiOverlay: true,
                            initialSelection: 'us',
                            onChanged: (c) {
                              // print(c!.dialCode);
                            },
                          ),
                        ),
                        SizedBox(width: 25),
                        Expanded(
                          child: TextFormField(
                            controller: phoneController,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Phone Number",
                            ),
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              MaskTextInputFormatter(mask: "(###) ###-####"),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Center(
                      child: Text(
                    "We'll send OTP for verification",
                    style: subHeadingStyle14MBGrey(),
                  )),
                  const SizedBox(height: 50),
                  Padding(
                    padding: const EdgeInsets.only(left: 15),
                    child: Text(
                      "EMAIL ADDRESS",
                      style: headingStyle14MBGrey(),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    // height:
                    // 40,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                        color: white,
                        border: Border.all(color: const Color(0xffDDE0ED)),
                        borderRadius: BorderRadius.circular(32)),
                    child: TextFormField(
                      controller: emailController,
                      decoration: const InputDecoration(border: InputBorder.none),
                      // validator: (email) {
                      //   if (email!.isEmpty) {
                      //     // print("sdjfkjasbdf");
                      //   }
                      //   if (!isValidEmail(email)) {
                      //     // return "Enter valid email";
                      //     showDialog(
                      //         useSafeArea: true,
                      //         barrierDismissible: false,
                      //         context: context,
                      //         builder: (context) {
                      //           return Center(
                      //             child: Padding(
                      //               padding: const EdgeInsets.all(20.0),
                      //               child: Material(
                      //                 borderRadius: BorderRadius.circular(5),
                      //                 child: invalidEmail(context),
                      //               ),
                      //             ),
                      //           );
                      //         });
                      //         return "" ;
                      //   }
                      //   return null ;

                      // },
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: Text(
                      "PASSWORD",
                      style: headingStyle14MBGrey(),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    // height:
                    // 40,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                        color: white,
                        border: Border.all(color: const Color(0xffDDE0ED)),
                        borderRadius: BorderRadius.circular(32)),
                    child: TextFormField(
                      obscureText: true,
                      controller: passwordController,
                      decoration: const InputDecoration(border: InputBorder.none),
                      // validator: (value) =>
                      //     value!.isEmpty ? 'Password can\'t be empty' : null,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: Text(
                      "CONFIRM PASSWORD",
                      style: headingStyle14MBGrey(),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    // height:
                    // 40,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                        color: white,
                        border: Border.all(color: const Color(0xffDDE0ED)),
                        borderRadius: BorderRadius.circular(32)),
                    child: TextFormField(
                      controller: confirmPasswordController,
                      obscureText: true,
                      decoration: const InputDecoration(border: InputBorder.none),
                      // validator: (value) {
                      //   if (passwordController.text != value) {
                      //     showDialog(
                      //         useSafeArea: true,
                      //         barrierDismissible: false,
                      //         context: context,
                      //         builder: (context) {
                      //           return Center(
                      //             child: Padding(
                      //               padding: const EdgeInsets.all(20.0),
                      //               child: Material(
                      //                 borderRadius: BorderRadius.circular(5),
                      //                 child: passwordsNotMatch(context),
                      //               ),
                      //             ),
                      //           );
                      //         });
                      //       return  ;
                      //   }
                      // return null ;
                      // },
                    ),
                  ),
                  const SizedBox(height: 80),
                  GestureDetector(
                      onTap: () {
                        if (isValidEmail(emailController.text) == false) {
                          // return "Enter valid email";
                          showDilaogBox(context, invalidEmail(context));
                        } else if (passwordController.text !=
                            confirmPasswordController.text) {
                          showDilaogBox(context, passwordsNotMatch(context));
                        } else {
                          // print("succesfull");
                          navigateForwardRemoveUntil(context, CustomerOtpCode());
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: button("Continue"),
                      )),
                  // const SizedBox(height: 80),
                ],
              ),
            ),
          )),
        ),
      ),
    );
  }
}
