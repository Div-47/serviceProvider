import 'dart:io';

import "package:flutter/material.dart";
import 'package:service_provider/interfaces/image_pick_interface.dart';
import 'package:service_provider/screens/notifications.dart';
import 'package:service_provider/screens/privacy_policy.dart';
import 'package:service_provider/screens/profile/profile_update.dart';

import 'package:service_provider/screens/support.dart';
import 'package:service_provider/screens/terms_of_use.dart';
import 'package:service_provider/screens/welcome.dart';
import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/camera_and_gallery_utility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';
import 'package:service_provider/widgets/buttons.dart';

class InfoCustomer extends StatefulWidget {
  InfoCustomer({Key? key}) : super(key: key);

  @override
  _InfoCustomerState createState() => _InfoCustomerState();
}

class _InfoCustomerState extends State<InfoCustomer>
    implements PickImageListener {
  File? profileImage;
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Scaffold(
        body: GestureDetector(
          onTap: () {
            FocusScopeNode currentFocus = FocusScope.of(context);
            if (!currentFocus.hasPrimaryFocus) {
              currentFocus.unfocus();
            }
          },
          child: Container(
            height: double.infinity,
            width: double.infinity,
            color: app_background_color,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: 250,
                    child: Stack(
                      children: [
                        SizedBox(
                          height: const Size.fromHeight(200.0).height,
                          child: AppBar(
                            backgroundColor: app_color,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                top: 105,
                                right: 0,
                                left: 0,
                                child: Container(
                                  height: 150,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  decoration: const BoxDecoration(
                                      color: white,
                                      borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(15),
                                          topRight: Radius.circular(15))),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [],
                                  ),
                                ),
                              ),
                              Positioned(
                                  top: 50,
                                  child: Column(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(1),
                                        decoration: BoxDecoration(
                                            color: white,
                                            borderRadius:
                                                BorderRadius.circular(15)),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          child: profileImage == null
                                              ? Image.asset(
                                                  "assets/icons/avatar2.png",
                                                  fit: BoxFit.cover,
                                                  height: 120,
                                                  width: 120,
                                                )
                                              : Image.file(
                                                  profileImage!,
                                                  fit: BoxFit.cover,
                                                  height: 120,
                                                  width: 120,
                                                ),
                                        ),
                                      ),
                                      const SizedBox(height: 15),
                                      Text("SELENA LENNIS",
                                          style: headingStyle14MBDarkGrey()),
                                      Text("Freelab88@gmail.com",
                                          style: headingStyle14MBDarkGrey())
                                    ],
                                  ))
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Container(
                      height: 500,
                      decoration: BoxDecoration(
                          color: white,
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(12),
                              bottomRight: Radius.circular(12))),
                      // padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 40),
                          Material(
                            color: white,
                            child: InkWell(
                              onTap: () {
                                navigateForward(context, Notifications());
                              },
                              child: ListTile(
                                leading: Image.asset(
                                    "assets/icons/info_notification.png"),
                                title: Text(
                                  'Notifications',
                                  style: headingStyle16MBDarkGrey(),
                                ),
                                trailing: Icon(Icons.arrow_forward_ios,
                                    color: app_color),
                              ),
                            ),
                          ),
                          SizedBox(height: 20),
                          Material(
                            color: white,
                            child: InkWell(
                              onTap: () {
                                navigateForward(context, PrivacyPolicy());
                              },
                              child: ListTile(
                                leading: Image.asset(
                                    "assets/icons/info_privacy_policy.png"),
                                title: Text(
                                  'Privacy Policy',
                                  style: headingStyle16MBDarkGrey(),
                                ),
                                trailing: Icon(Icons.arrow_forward_ios,
                                    color: app_color),
                              ),
                            ),
                          ),
                          SizedBox(height: 20),
                          Material(
                            color: white,
                            child: InkWell(
                              onTap: () {
                                navigateForward(context, TermsOfUse());
                              },
                              child: ListTile(
                                leading: Image.asset(
                                    "assets/icons/info_terms_of_use.png"),
                                title: Text(
                                  'Terms Of Use',
                                  style: headingStyle16MBDarkGrey(),
                                ),
                                trailing: Icon(Icons.arrow_forward_ios,
                                    color: app_color),
                              ),
                            ),
                          ),
                          SizedBox(height: 20),
                          Material(
                            color: white,
                            child: InkWell(
                              onTap: () {
                                navigateForward(context, Support());
                              },
                              child: ListTile(
                                leading: Image.asset(
                                    "assets/icons/info_support.png"),
                                title: Text(
                                  'Support',
                                  style: headingStyle16MBDarkGrey(),
                                ),
                                trailing: Icon(Icons.arrow_forward_ios,
                                    color: app_color),
                              ),
                            ),
                          ),
                          SizedBox(height: 40),
                          Material(
                            color: white,
                            child: InkWell(
                              onTap: () {
                                navigateForwardRemoveUntil(context, Welcome());
                              },
                              child: ListTile(
                                leading:
                                    Image.asset("assets/icons/info_logout.png"),
                                title: Text(
                                  'Log Out',
                                  style: headingStyle16MBDarkGrey(),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                  // SizedBox(
                  //   height: 365,
                  //   child: Stack(
                  //     children: [
                  //       Padding(
                  //         padding: const EdgeInsets.only(left: 20.0, right: 20),
                  //         child: Container(
                  //           height: 340,
                  //           width: double.infinity,
                  //           padding: const EdgeInsets.all(10),
                  //           decoration: BoxDecoration(
                  //               color: white,
                  //               borderRadius: BorderRadius.circular(15)),
                  //           child: Column(
                  //             children: [
                  //               TextFormField(
                  //                 decoration: InputDecoration(
                  //                     labelText: 'Name',
                  //                     contentPadding:
                  //                         const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  //                     enabledBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     ),
                  //                     focusedBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     )),
                  //               ),
                  //               const SizedBox(
                  //                 height: 20,
                  //               ),
                  //               TextFormField(
                  //                 decoration: InputDecoration(
                  //                     labelText: 'Email',
                  //                     contentPadding:
                  //                         const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  //                     enabledBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     ),
                  //                     focusedBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     )),
                  //               ),
                  //               const SizedBox(
                  //                 height: 20,
                  //               ),
                  //               TextFormField(
                  //                 decoration: InputDecoration(
                  //                     labelText: 'Phone Number',
                  //                     contentPadding:
                  //                         const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  //                     enabledBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     ),
                  //                     focusedBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     )),
                  //               ),
                  //               const SizedBox(
                  //                 height: 20,
                  //               ),
                  //               TextFormField(
                  //                 obscureText: true,
                  //                 decoration: InputDecoration(
                  //                     labelText: 'Password',
                  //                     contentPadding:
                  //                         const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  //                     enabledBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     ),
                  //                     focusedBorder: OutlineInputBorder(
                  //                       borderSide: const BorderSide(
                  //                           width: 1, color: Color(0xff808080)),
                  //                       borderRadius: BorderRadius.circular(5),
                  //                     )),
                  //               )
                  //             ],
                  //           ),
                  //         ),
                  //       ),

                  //     ],
                  //   ),
                  // )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void openCamera() async {
    print("open camera");
    setState(() async {
      profileImage = await pickFromCamera();
    });
    // TODO: implement openCamera
  }

  @override
  void openGallery() async {
    setState(() async {
      profileImage = await pickFromGallery();
    });
    print("open gallery");

    // TODO: implement openGallery
  }
}
