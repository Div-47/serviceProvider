import "package:flutter/material.dart";

import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';
import 'package:service_provider/widgets/buttons.dart';

class Support extends StatefulWidget {
  Support({Key? key}) : super(key: key);

  @override
  _SupportState createState() => _SupportState();
}

class _SupportState extends State<Support> {
TextEditingController nameController = TextEditingController() ;
TextEditingController emailController = TextEditingController() ;
TextEditingController writeUsController = TextEditingController() ;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
                centerTitle: true,

        backgroundColor: app_color,
        title: Text("Support", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          child: SafeArea(
              child: Center(
                child: SingleChildScrollView(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                     TextFormField(
                       controller: nameController,
                                  decoration: InputDecoration(
                                      labelText: 'Name',
                                      labelStyle: headingStyle14MBDarkGrey(),
                                      contentPadding:
                                          const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      )),
                                ),
                                SizedBox(height:20),
                                 TextFormField(
                                   controller: emailController,
                                  decoration: InputDecoration(
                                      labelText: 'Email',
                                      labelStyle: headingStyle14MBDarkGrey(),
                                      contentPadding:
                                          const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      )),
                                ), SizedBox(height:20),
                                 TextFormField(
                                   controller: writeUsController,
                                   maxLines: 10,
                                  decoration: InputDecoration(
                                      labelText: 'Write here',
                                       
                                      labelStyle: headingStyle14MBDarkGrey(),
                                      // contentPadding:
                                      //     const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                          
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                            width: 1, color: Color(0xff808080)),
                                        borderRadius: BorderRadius.circular(5),
                                      )),
                                ),
                              SizedBox(height:120),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal:20.0),
                                child: button("Send"),
                              )
                  
                
                ],
            ),
          ),
              )),
        ),
      ),
    );
  }
}