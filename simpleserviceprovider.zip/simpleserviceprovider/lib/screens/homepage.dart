import "package:flutter/material.dart";
import 'package:service_provider/ListItemWidget/home_categories.dart';
import 'package:service_provider/screens/chat.dart';
import 'package:service_provider/screens/home.dart';
import 'package:service_provider/screens/info_customer.dart';
import 'package:service_provider/screens/info_enterpreneur.dart';
import 'package:service_provider/screens/profile/profile_update.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class Homepage extends StatefulWidget {
  final String user ;
  Homepage(this.user) ;
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   backgroundColor: app_color,
        //   title: Text("Home", style: headingStyle20MBWhite()),
        // ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          child: Column(
            children: [
              Visibility(visible: _currentIndex == 0, child: Home()),
              Visibility(
                  visible: _currentIndex == 1, child: Expanded(child: Chat())),
              Visibility(visible: _currentIndex == 2, child: widget.user == "customer" ? ProfileUpdate(user: "customer", ) :ProfileUpdate(user:"enterpreneur") ),
              Visibility(visible: _currentIndex == 3, child: widget.user == "customer" ? InfoCustomer() :InfoProvider())
            ],
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            selectedIconTheme: const IconThemeData(color: app_color),
            selectedItemColor: app_color,
            currentIndex: _currentIndex,
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            items: [
              BottomNavigationBarItem(
                  icon: Image.asset(
                    "assets/icons/home.png",
                    height: 24,
                    width: 24,
                    color: _currentIndex == 0 ? app_color : Color(0xffC5CEE0),
                  ),
                  label: "Home"),
              BottomNavigationBarItem(
                  icon: Image.asset("assets/icons/chat.png",
                      height: 24,
                      width: 24,
                      color:
                          _currentIndex == 1 ? app_color : Color(0xffC5CEE0)),
                  label: "Messsages"),
              BottomNavigationBarItem(
                  icon: Image.asset("assets/icons/user.png",
                      height: 24,
                      width: 24,
                      color:
                          _currentIndex == 2 ? app_color : Color(0xffC5CEE0)),
                  label: "Profile"),
              BottomNavigationBarItem(
                  icon: Image.asset("assets/icons/info.png",
                      height: 24,
                      width: 24,
                      color:
                          _currentIndex == 3 ? app_color : Color(0xffC5CEE0)),
                  label: "Info"),
            ]));
  }
}
