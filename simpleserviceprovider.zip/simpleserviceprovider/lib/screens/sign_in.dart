import "package:flutter/material.dart";
import 'package:service_provider/screens/current_package.dart';
import 'package:service_provider/screens/homepage.dart';

import 'package:service_provider/screens/password_reset/password_reset.dart';
import 'package:service_provider/screens/sign_up.dart';
import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/utility.dart/validation.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';

class SignIn extends StatefulWidget {
  const SignIn({Key? key}) : super(key: key);

  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: app_background_color,
      appBar: AppBar(
                centerTitle: true,

        backgroundColor: app_color,
        title: Text("Sign In", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);

          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          child: SafeArea(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 100,
                  ),
                  Text(
                    "Welcome Back!",
                    style: headingStyle21MBAppColor(),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "Sign in to continue",
                    style: headingStyle14MBBlack(),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(left: 15),
                    child: Text(
                      "EMAIL ADDRESS",
                      style: headingStyle14MBGrey(),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    // height:
                    // 40,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                        color: white,
                        border: Border.all(color: const Color(0xffDDE0ED)),
                        borderRadius: BorderRadius.circular(32)),
                    child: TextFormField(
                      controller: emailController,
                      decoration:
                          const InputDecoration(border: InputBorder.none),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Password",
                          style: headingStyle14MBGrey(),
                        ),
                        GestureDetector(
                          onTap: () {
                            navigateForward(context, PasswordReset());
                          },
                          child: Text(
                            "Forgot Password?",
                            style: headingStyle16MBAppColor(),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    // height:
                    // 40,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                        color: white,
                        border: Border.all(color: const Color(0xffDDE0ED)),
                        borderRadius: BorderRadius.circular(32)),
                    child: TextFormField(
                      controller: passwordController,
                      decoration:
                          const InputDecoration(border: InputBorder.none),
                    ),
                  ),
                  const SizedBox(height: 80),
                  GestureDetector(
                      onTap: () {
                        if (isValidEmail(emailController.text) == false) {
                          // return "Enter valid email";
                          showDilaogBox(context, invalidEmail(context));
                        } else {
                          // print("succesfull");
                          navigateForwardRemoveUntil(context,emailController.text == "customer@gmail.com" ? Homepage("customer") : CurrentPackage());
                        }
                      },
                      child: signInAndSignupButton("Sign in")),
                  const SizedBox(height: 80),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Dont have an account ?",
                        style: headingStyle14MBGrey(),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      GestureDetector(
                        onTap: () {
                          navigateForward(context, SignUp());
                        },
                        child: Text(
                          "Sign Up",
                          style: headingStyle16MBAppColor(),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget signInAndSignupButton(String title) {
    return Container(
        height: 50,
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12), color: app_color),
        child: Center(
          child: Text(title, style: headingStyle20MBWhite()),
        ));
  }
}
