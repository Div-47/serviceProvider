import 'dart:async';

import "package:flutter/material.dart";
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:service_provider/screens/enterpreneur/enterpreneur_profile.dart';

import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';

class Categories extends StatefulWidget {
  Categories({Key? key}) : super(key: key);

  @override
  State<Categories> createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  Completer<GoogleMapController> _controller = Completer();

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  static final CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);
  int _currentIndex = 0;
  List categories = ["Physics", "Math", "English", "Spanish", "Enterpreneur"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
                centerTitle: true,

        backgroundColor: app_color,
        title: Text("Categories", style: headingStyle20MBWhite()),
      ),
      body: Stack(
        children: [
          GoogleMap(
            mapType: MapType.hybrid,
            initialCameraPosition: _kGooglePlex,
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
            },
          ),
          Container(
            height: 60,
            width: double.infinity,
            color: white,
            child: ListView.builder(
                itemCount: 5,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  return tabs(categories[index], index);
                }),
          ),
          Positioned(
            bottom: 10,
            left: 0,
            right: 0,
            child: Container(
              height: 160,
              child: ListView.builder(
                  itemCount: 5,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return enterpreneur("title", index);
                  }),
            ),
          ),
        ],
      ),
      // bottomNavigationBar: BottomNavigationBar(
      //       type: BottomNavigationBarType.fixed,
      //       selectedIconTheme: const IconThemeData(color: app_color),
      //       selectedItemColor: app_color,
      //       currentIndex: _currentIndex,
      //       onTap: (index) {
      //         setState(() {
      //           _currentIndex = index;
      //         });
      //       },
      //       items: [
      //         BottomNavigationBarItem(
      //             icon: Image.asset(
      //               "assets/icons/home.png",
      //               height: 24,
      //               width: 24,
      //               color: _currentIndex == 0 ? app_color : Color(0xffC5CEE0),
      //             ),
      //             label: "Home"),
      //         BottomNavigationBarItem(
      //             icon: Image.asset("assets/icons/chat.png",
      //                 height: 24,
      //                 width: 24,
      //                 color:
      //                     _currentIndex == 1 ? app_color : Color(0xffC5CEE0)),
      //             label: "Messsages"),
      //         BottomNavigationBarItem(
      //             icon: Image.asset("assets/icons/user.png",
      //                 height: 24,
      //                 width: 24,
      //                 color:
      //                     _currentIndex == 2 ? app_color : Color(0xffC5CEE0)),
      //             label: "Profile"),
      //         BottomNavigationBarItem(
      //             icon: Image.asset("assets/icons/info.png",
      //                 height: 24,
      //                 width: 24,
      //                 color:
      //                     _currentIndex == 3 ? app_color : Color(0xffC5CEE0)),
      //             label: "Info"),
      //       ])
    );
  }

  Widget tabs(String title, int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _currentIndex = index;
        });
      },
      child: Padding(
        padding:
            const EdgeInsets.only(top: 10.0, bottom: 10, left: 5, right: 5),
        child: Container(
          height: 29,
          width: 120,
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
            color: _currentIndex == index ? app_color : Color(0xffEFEFF4),
          ),
          child: Center(
              child: Text(title,
                  style: _currentIndex == index
                      ? headingStyle14MBWhite()
                      : headingStyle14MBDarkGrey())),
        ),
      ),
    );
  }

  Widget enterpreneur(String title, int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          // _currentIndex = index;
          navigateForward(context, EnterpreneurProfile()) ;
        });
      },
      child: Padding(
        padding:
            const EdgeInsets.only(top: 10.0, bottom: 10, left: 5, right: 5),
        child: Container(
            // height: 100,
            width: 310,
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: white,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset(
                          "assets/icons/avatar.png",
                          fit: BoxFit.cover,
                          height: 100,
                          width: 100,
                        )),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Richard Moors",
                              style: headingStyle16MBDarkGrey()),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Icon(
                                Icons.location_on,
                                color: Color(0xffC8C7CC),
                              ),
                              Text(
                                "0.31 mi away",
                                style: headingStyle14MBDarkGrey(),
                              )
                            ],
                          ),
                          Text(
                            "Physics",
                            style: headingStyle16MBAppColor(),
                          ),
                        ],
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios, color: app_color)
                  ],
                )
              ],
            )),
      ),
    );
  }
}
