import 'package:flutter/material.dart';
import 'package:service_provider/screens/password_reset/new_password.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

class PasswordReset extends StatefulWidget {
  PasswordReset({Key? key}) : super(key: key);

  @override
  State<PasswordReset> createState() => _PasswordResetState();
}

class _PasswordResetState extends State<PasswordReset> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: app_background_color,
      appBar: AppBar(
        backgroundColor: app_color,
                centerTitle: true,

        title: Text("Password Reset", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          child: SafeArea(
              child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(
                  height: 40,
                ),
                Container(
                  height: MediaQuery.of(context).size.height * .68,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5), color: white),
                  child: Column(children: [
                    const SizedBox(
                      height: 40,
                    ),
                    Text(
                      "Check your email for\n4 digit code.",
                      style: headingStyle14MBDarkGrey(),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(
                      height: 70,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _textFieldOTP(first: true, last: false),
                        const SizedBox(width: 10),
                        _textFieldOTP(first: false, last: false),
                        const SizedBox(width: 10),
                        _textFieldOTP(first: false, last: false),
                        const SizedBox(width: 10),
                        _textFieldOTP(first: false, last: true)
                      ],
                    ),
                    const SizedBox(
                      height: 70,
                    ),
                    Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "No Code Recieved?",
                              style: headingStyle14MBDarkGrey(),
                            ),
                            Text(
                              "Resend Now!",
                              style: headingStyle16MBAppColor(),
                            )
                          ],
                        )),
                    const SizedBox(
                      height: 70,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: GestureDetector(
                          onTap: () {
                            navigateForward(context, NewPassword());
                          },
                          child: button("Reset")),
                    )
                  ]),
                )
              ],
            ),
          )),
        ),
      ),
    );
  }

  Widget _textFieldOTP({bool? first, last}) {
    return Container(
      // padding: EdgeInsets.only(left:5,right:5),

      height: 65,
      child: AspectRatio(
        aspectRatio: 0.9,
        child: TextField(
          autofocus: true,
          onChanged: (value) {
            if (value.length == 1 && last == false) {
              FocusScope.of(context).nextFocus();
            }
            if (value.isEmpty && first == false) {
              FocusScope.of(context).previousFocus();
            }
          },
          showCursor: false,
          readOnly: false,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          keyboardType: TextInputType.number,
          maxLength: 1,
          decoration: InputDecoration(
            counter: Offstage(),
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 2, color: Colors.black12),
                borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(width: 2, color: Colors.purple),
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ),
    );
  }
}
