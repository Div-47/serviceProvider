import 'package:flutter/material.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/buttons.dart';

class NewPassword extends StatefulWidget {
  NewPassword({Key? key}) : super(key: key);

  @override
  State<NewPassword> createState() => _NewPasswordState();
}

class _NewPasswordState extends State<NewPassword> {
  TextEditingController passwordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: app_background_color,
      appBar: AppBar(
        backgroundColor: app_color,
                centerTitle: true,

        title: Text("Password Reset", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          child: SafeArea(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 80),
                  Padding(
                    padding: const EdgeInsets.only(left: 15),
                    child: Text(
                      "NEW PASSWORD",
                      style: headingStyle14MBGrey(),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    // height:
                    // 40,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                        color: white,
                        border: Border.all(color: const Color(0xffDDE0ED)),
                        borderRadius: BorderRadius.circular(32)),
                    child: TextFormField(
                      obscureText: true,
                      controller: passwordController,
                      decoration:
                          const InputDecoration(border: InputBorder.none),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(left: 15, right: 15),
                    child: Text(
                      "CONFIRM PASSWORD",
                      style: headingStyle14MBGrey(),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    // height:
                    // 40,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    decoration: BoxDecoration(
                        color: white,
                        border: Border.all(color: const Color(0xffDDE0ED)),
                        borderRadius: BorderRadius.circular(32)),
                    child: TextFormField(
                      obscureText: true,
                      controller: passwordController,
                      decoration:
                          const InputDecoration(border: InputBorder.none),
                    ),
                  ),
                  const SizedBox(height: 80),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal:20.0),
                    child: button("Save Now"),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
