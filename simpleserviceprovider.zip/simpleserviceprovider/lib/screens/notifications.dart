import "package:flutter/material.dart";
import 'package:service_provider/ListItemWidget/notifications_list_item.dart';

import 'package:service_provider/utility.dart/baseUtility.dart';
import 'package:service_provider/utility.dart/colors.dart';
import 'package:service_provider/utility.dart/navigation_utility.dart';
import 'package:service_provider/utility.dart/text_style.dart';
import 'package:service_provider/widgets/AlertDialogs.dart';
import 'package:service_provider/widgets/buttons.dart';

class Notifications extends StatefulWidget {
  Notifications({Key? key}) : super(key: key);

  @override
  _NotificationsState createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  @override
  Widget build(BuildContext context) {
   int rightBorderRadius = 15 ;
    return Scaffold(
      appBar: AppBar(
                centerTitle: true,

        backgroundColor: app_color,
        title: Text("Notifications", style: headingStyle20MBWhite()),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
          }
        },
        child: Container(
          height: double.infinity,
          width: double.infinity,
          color: app_background_color,
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          child: SafeArea(
              child: SingleChildScrollView(
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,

              children: [
                ListView.builder(
                    itemCount: 5,
                    padding: EdgeInsets.only(top:20,bottom:20),
                    shrinkWrap: true,
                    // physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                    return Dismissible(
                      key: Key(index.toString()),
                    
                      background: slideLeftBackground(),
                      
                      child: NotificationsListItem());
                  })
                
              // noNewNotifications()
              ],
            ),
          )),
        ),
      ),
    );
  }
  Widget noNewNotifications(){
    return Column(children:[
       Image.asset("assets/icons/notifications_off.png"),
                 Text("No New Notificationss", style: headingStyle21MBAppColor(),)
    ]);
  }
  Widget slideLeftBackground() {
  return Padding(
      padding: EdgeInsets.only(top: 8),
    child: Container(
     
        height: 100,
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: red,
          ),
      child: Align(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
           Image.asset("assets/icons/white_bin.png"),
           
            SizedBox(
              width: 20,
            ),
          ],
        ),
        alignment: Alignment.centerRight,
      ),
    ),
  );
}
  
}