
import "package:flutter/material.dart" ;

import 'package:google_fonts/google_fonts.dart';
import 'package:service_provider/utility.dart/colors.dart';

headingStyle16MBWhite() {
  return GoogleFonts.poppins(
      color: white, fontSize: 16, fontWeight: FontWeight.w500);
}
headingStyle16MBDarkGrey() {
  return GoogleFonts.poppins(
      color: Color(0xff353B50), fontSize: 16, fontWeight: FontWeight.w500);
}
headingStyle20MBWhite() {
  return GoogleFonts.poppins(
      color: white, fontSize: 20, fontWeight: FontWeight.w500);
}
headingStyle20MBDarkGrey() {
  return GoogleFonts.poppins(
      color: Color(0xff353B50), fontSize: 20, fontWeight: FontWeight.w500);
}

headingStyle27MBWhite() {
  return GoogleFonts.poppins(
      color: white, fontSize: 27, fontWeight: FontWeight.w500);
}
headingStyle21MBAppColor() {
  return GoogleFonts.poppins(
      color: app_color, fontSize: 21, fontWeight: FontWeight.w600);
}
headingStyle21MBDarkGrey() {
  return GoogleFonts.poppins(
      color: darkGrey, fontSize: 21, fontWeight: FontWeight.w600);
}
headingStyle16MBAppColor() {
  return GoogleFonts.poppins(
      color: app_color, fontSize: 16, fontWeight: FontWeight.w500);
}
headingStyle16EBAppColor() {
  return GoogleFonts.poppins(
      color: app_color, fontSize: 16, fontWeight: FontWeight.w900);
}
headingStyle14MBBlack() {
  return GoogleFonts.poppins(
      color: black, fontSize: 14, fontWeight: FontWeight.w500);
}
headingStyle14MBDarkGrey() {
  return GoogleFonts.poppins(
      color: Color(0xff353B50), fontSize: 14, fontWeight: FontWeight.w500);
}
headingStyle14MBWhite() {
  return GoogleFonts.poppins(
      color: white, fontSize: 14, fontWeight: FontWeight.w500);
}
headingStyle14MBGrey() {
  return GoogleFonts.poppins(
      color: Color(0xffB0BAC9), fontSize: 14, fontWeight: FontWeight.w500);
}
subHeadingStyle14MBGrey() {
  return GoogleFonts.poppins(
      color: Color(0xff7E8395), fontSize: 14, fontWeight: FontWeight.w500);
}
subHeadingStyle12MBGrey() {
  return GoogleFonts.poppins(
      color: Color(0xff7E8395), fontSize: 12, fontWeight: FontWeight.w500);
}
