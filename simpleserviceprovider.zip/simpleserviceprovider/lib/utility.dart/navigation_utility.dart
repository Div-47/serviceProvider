import "package:flutter/material.dart" ;

void navigateForward(BuildContext context , Widget screen ) {
 Navigator.push(context, MaterialPageRoute(builder: (context) => screen ));
}
void navigateForwardRemoveUntil(BuildContext context , Widget screen ) {
  Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                  builder: (context) => screen),
                              (Route<dynamic> route) => false);
}
