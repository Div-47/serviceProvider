import 'package:flutter/material.dart';

void hideKeyboard(BuildContext context) {
  FocusScope.of(context).requestFocus(FocusNode());
}

Future showDilaogBox(BuildContext context, Widget alert) {
  return showDialog(
      useSafeArea: true,
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Material(
              borderRadius: BorderRadius.circular(5),
              child: alert,
            ),
          ),
        );
      });
}

Future showTransparentDilaogBox(BuildContext context, Widget alert) {
  return showDialog(
      useSafeArea: true,
      barrierDismissible: true,
      context: context,
      builder: (context) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: StatefulBuilder(
              builder: (context,setState) {
                return Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(5),
                  child: alert,
                );
              }
            ),
          ),
        );
      });
}
