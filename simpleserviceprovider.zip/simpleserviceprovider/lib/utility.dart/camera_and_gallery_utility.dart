import 'dart:io';

import 'package:image_picker/image_picker.dart';

Future pickFromCamera() async {
  final pickedFiled = await ImagePicker().pickImage(source: ImageSource.camera);
  return File(pickedFiled!.path);
}
Future pickFromGallery() async {
  final pickedFiled = await ImagePicker().pickImage(source: ImageSource.gallery);
  return File(pickedFiled!.path);
}
