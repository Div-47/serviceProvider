abstract class PickImageListener {
  void openGallery();

  void openCamera();
}