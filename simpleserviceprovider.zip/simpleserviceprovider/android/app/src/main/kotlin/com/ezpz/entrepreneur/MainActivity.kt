package com.ezpz.entrepreneur

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
